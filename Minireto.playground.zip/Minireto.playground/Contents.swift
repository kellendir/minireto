//: Playground - noun: a place where people can play

import UIKit

var numeros = 0...100

for numero in numeros{
    
    if numero>=30 && numero<=40{
    
        print(numero, "Viva Swift!!")
    }else if numero%5==0{
        
            print(numero, "Bingo!!")
    }else if numero%2==0{
    
        print(numero, "Es par")
    }else {
    
        print(numero, "Es impar")
    }
    
    
}

/* 
  Dado que no especifican si algúna condición tiene mas prioridad que otra , esta es la unica manera que se me ocurre que acierte más en las condiciones que imponen. No obstante, para numero como el 30, 35 o 40 por ejemplo, son numeros divisibles por 5, pares e impares y están dentro del rango "Viva Swift", no veo que hayan explicado como poner más de una condición para un mismo numero con lo cual , espero haber acertado lo máximo posible.
 */
